<?php
$dbname = 'proyect';
$dbuser = 'ariel';
$dbpass = 'ariel';
$dbhost = '192.168.64.3';

$conexion = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
if (!$conexion){
    die ("No hay conexion: ".mysqli_connect_error());
}

$nombre=$_POST["idadminnombrebox"];
$pass=$_POST["idadminpass"];
$tipousuario=1;
$id=$_POST["idadmintextbox"];
$email=$_POST["idamdinemail"];
$departamento=" ";

$existe=mysqli_query($conexion,"SELECT * FROM `usuarios` WHERE id='$id'");
$array = mysqli_fetch_array($existe);
$existeid = $array ['id'];


if ($existeid  == $id ){
    ?>
    <?php
    include("cusuarios.php");
    ?>
    <script LANGUAJE="JavaScript"> alert("ID o correo existente, intente otra vez")</script>
    <?php
}  

else{
    mysqli_query($conexion,"INSERT INTO `usuarios`(`nombreusuario`, `contrasena`, `tipousuario`, `id`, `email`, `departamento`) VALUES ('$nombre','$pass',$tipousuario,'$id','$email','$departamento')");

    ?>
   <?php
   include("cusuarios.php");
   ?>
   <script LANGUAJE="JavaScript"> alert("Administrador creado con exito!")</script>
   <?php
}
