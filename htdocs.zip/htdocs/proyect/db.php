<?php
//$conexion=mysqli_connect("192.168.64.2","ariel","ariel","proyect");
//$conexion=new PDO("mysql:host=192.168.64.2;port=3306;dbname=proyect", 'ariel', 'ariel');

$dbname = 'proyect';
$dbuser = 'ariel';
$dbpass = 'ariel';
$dbhost = '192.168.64.3';
//$dbhost = '127.0.0.1';

$conexion = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
if (!$conexion){
    die ("No hay conexion: ".mysqli_connect_error());
}


?>