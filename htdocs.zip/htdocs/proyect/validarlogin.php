<?php

include ('db.php');

$id= $_POST["id"];
$contrasena= $_POST["contrasena"];

$consulta=mysqli_query($conexion,"SELECT * FROM usuarios where id='$id' and contrasena='$contrasena'");

$array = mysqli_fetch_array($consulta);
$tipousuario = $array ['tipousuario'];
//echo $tipousuario;


if ($tipousuario == 1):
    session_start();
    $_SESSION["id"]=$id;
    header("location: siteadmin/index.html");
    
elseif ($tipousuario == 2): 
    session_start();
    $_SESSION["id"]=$id;
    header("location: usuario/index.html");
else:
  ?>
   <?php
   //header("location: index.html");
   include("index.html");
   ?>
   <script LANGUAJE="JavaScript"> alert("Usuario o contraseña incorrecta - Intente nuevamente!")</script>
    <!-- <h1 class="bad">Usuario o contraseña incorrecta - Intente nuevamente!</h1> </script> -->
   <?php
endif;

mysqli_free_result($consulta);
mysqli_close($conexion);
