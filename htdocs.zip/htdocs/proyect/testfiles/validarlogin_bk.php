<?php


include ('db.php');

$id= $_POST["id"];
$contrasena= $_POST["contrasena"];

session_start();
$_SESSION["id"]=$id;

$consulta=mysqli_query($conexion,"SELECT * FROM usuarios where id='$id' and contrasena='$contrasena'");

$res = mysqli_num_rows($consulta);
//echo mysqli_num_rows($consulta); //si muestra 1 es que devolvio el usuario encontrado

if ($res){
    
    header("location: home.html");

}else {
    ?>
    <?php
    //header("location: index.html");
    include("index.html");
    ?>
    <script LANGUAJE="JavaScript"> alert("Usuario o contraseña incorrecta - Intente nuevamente!")</script>
     <!-- <h1 class="bad">Usuario o contraseña incorrecta - Intente nuevamente!</h1> </script> -->
     <!-- <script LANGUAJE="JavaScript"> alert("Usuario o contraseña incorrecta - Intente nuevamente!")</script> -->
    <?php

}

mysqli_free_result($consulta);
mysqli_close($conexion);

