<?php
# Fill our vars and run on cli
# $ php -f db-connect-test.php

$dbname = 'proyect';
$dbuser = 'ariel';
$dbpass = 'ariel';
$dbhost = '192.168.64.2';

$link = mysqli_connect($dbhost, $dbuser, $dbpass) or die("No se puede conectar a la host: '$dbhost'");
mysqli_select_db($link, $dbname) or die("no se pudo abrir la db: '$dbname'");


// $usuario='usuario';
// $contrasena='contrasena';
// $consulta="SELECT * FROM usuarios where nombreusuario='$usuario' and contrasena='$contrasena'";
// print $consulta;


$test_query = "SHOW TABLES FROM $dbname";
$result = mysqli_query($link, $test_query);

$tblCnt = 0;
while($tbl = mysqli_fetch_array($result)) {
  $tblCnt++;
  #echo $tbl[0]."<br />\n";
}

if (!$tblCnt) {
  echo "No hay tablas<br />\n";
} else {
  echo "Hay $tblCnt tabla(s)<br />\n";
} 
?>
