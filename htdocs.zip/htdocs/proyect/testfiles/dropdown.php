<?php
$dbname = 'proyect';
$dbuser = 'ariel';
$dbpass = 'ariel';
$dbhost = '192.168.64.3';

$conexion = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
if (!$conexion){
    die ("No hay conexion: ".mysqli_connect_error());
}

$departamentos=mysqli_query($conexion,"SELECT * FROM `departamentos`");
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"> 

</head>
<body>
    


<div class="card" style="width: 18rem;">
  <ul class="list-group list-group-flush">
    
  <?php
        foreach ($departamentos as $row)
        {
            echo '<li value="'.$row["nombre"].'">'.$row["nombre"].'</li>';
        }
        ?>
        <a href="" class="btn btn-primary">Refrescar</a>

  </ul>
</div>


</body>
</html>