<?php

include ('db.php');

$id= $_POST["id"];
$contrasena= $_POST["contrasena"];

$consulta=mysqli_query($conexion,"SELECT * FROM usuarios where id='$id' and contrasena='$contrasena'");
$array = mysqli_fetch_array($consulta);
$tipousuario = $array ['tipousuario']?? "";


$conexion2 = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
$consulta2=mysqli_query($conexion2,"SELECT departamento FROM usuarios where id='$id' and contrasena='$contrasena'");
$array2 = mysqli_fetch_array($consulta2);
$depa = $array ['departamento']?? "";



if ($tipousuario == 1):
    session_start();
    $_SESSION["id"]=$id;
    header("location: siteadmin/index.php");
    
elseif ($tipousuario == 2): 
    session_start();
    $_SESSION["id"]=$id;
    $_SESSION["departamento"]=$depa;

    header("location: usuario/index.php");
else:
  ?>
   <?php
   //header("location: index.html");
 
   include("index.html");
   ?>
   <script LANGUAJE="JavaScript"> alert("Usuario o contraseña incorrecta - Intente nuevamente!")</script>
    <!-- <h1 class="bad">Usuario o contraseña incorrecta - Intente nuevamente!</h1> </script> -->
   <?php
endif;

mysqli_free_result($consulta);
mysqli_close($conexion);
