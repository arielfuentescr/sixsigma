<?php 
$dbname = 'proyect';
$dbuser = 'ariel';
$dbpass = 'ariel';
$dbhost = '127.0.0.1';

$conexion = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">


</head>


<body>



<?php

$totalbyusuario=mysqli_query($conexion," CALL `sp_totalbyusuario`('DevOps');");  

foreach($totalbyusuario as $data)
{

$Nombredelcolaborador[] = $data['Nombredelcolaborador'];
$Porcentajesigma[] = $data['Porcentajesigma'];
 
$r = rand(0,255); 
$g = rand(0,255); 
$b = rand(0,255); 
$color2[] = "rgb(".$r.",".$g.",".$b.")";
}
?>
 


<div>
<canvas id="graficoporusuarios"></canvas>
</div>
    

<script>
  const labels = <?php echo json_encode($Nombredelcolaborador)?>;
    const data = {
        labels: <?php echo json_encode($Nombredelcolaborador)?>,
        datasets: [{
            label: 'Porcentajes',
            data: <?php echo json_encode($Porcentajesigma)?>,
            backgroundColor: <?php echo json_encode($color2)?>,
            hoverOffset: 4
        }]
    };

  const config = 
  {
  type: 'doughnut',
  data: data,
  };
</script>
            
       
<script>
const graficoporusuarios = new Chart(
document.getElementById('graficoporusuarios'),
config
);
</script>



</body>
</html>