<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>



<body>
   
<?php
$dbname = 'proyect';
$dbuser = 'ariel';
$dbpass = 'ariel';
$dbhost = '127.0.0.1';

$conexion = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);

$totalbyusuario=mysqli_query($conexion," CALL `sp_totalbyusuario`('DevOps');");

while ($row = mysqli_fetch_array($totalbyusuario)){   
echo $row[0] . " "; echo $row[1] . "<br>";
}

 foreach($totalbyusuario as $data)
 {
 $Nombredelcolaborador[] = $data['Nombredelcolaborador'];
 $Porcentajesigma[] = $data['Porcentajesigma'];
 }

?>

<?php
include 'chartcircular.php';
?>
                      

<div>
<canvas id="myChart"></canvas>
</div>
    
<script>
  
  const labels = <?php echo json_encode($Nombredelcolaborador)?>;

  const data = {
    labels: labels,
    datasets: [{
      label: 'My First dataset',
      backgroundColor: 'rgb(255, 99, 132)',
      borderColor: 'rgb(255, 99, 132)',
      data: [0, 10, 5, 2, 20, 30, 45],
    }]
  };

  const config = {
    type: 'line',
    data: data,
    options: {}
  };

</script>


            <script>
            const myChart = new Chart(
            document.getElementById('myChart'),
            config
            );
            </script>


</body>
</html>