
<?php
$dbname = 'proyect';
$dbuser = 'ariel';
$dbpass = 'ariel';
$dbhost = '127.0.0.1';


$conexion = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
session_start();
$depaactuales = $_SESSION["departamento"];

if ($depaactuales == ""):
    header("location: ../index.html");
else:
endif;

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Mi Dashboard SixSigma</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Fonts-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Estilos del boostrap-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

   
    <div id="wrapper">

        <!-- MenuLado -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        

     

            <!-- Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Ir al Dashboard</span></a>
            </li>

    
          
            

        </ul>
        <!-- final MenuLado -->


       
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Contenido principal -->
            <div id="content">

                <!-- Top-->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                

                  
                    <ul class="navbar-nav ml-auto">

                        

                                            <!-- Usuario cerrar session -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <!--  <span class="mr-2 d-none d-lg-inline text-gray-600 small">Douglas McGee</span>--><img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
            
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- final Topbar -->

                <!-- comienzo pagina principal -->
                <div class="container-fluid">

                    <!-- Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Ir al Dashboard</h1>
                    </div>

                    <!-- Row -->
                    <div class="row">

                        <!-- Graficos -->
                        <div class="col-xl-8 col-lg-7">
                            <div class="card shadow mb-4">
                                <!-- Porcentaje Sigma de mi equipo -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Porcentaje Sigma de mi equipo</h6>
                                    <div class="dropdown no-arrow">
                                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                        </a>
                                    </div>
                                </div>
                                <!-- Body -->
                                <div class="card-body">
                               
                                <div class="embed-responsive embed-responsive-16by9">
                                 <iframe class="embed-responsive-item" src="/proyect/usuario/chartbarrasusuario.php"></iframe>
                                </div>  

                                </div>
                            </div>
                        </div>

                      
                        <div class="col-xl-4 col-lg-5">
                            <div class="card shadow mb-4">
                                <!-- Porcentaje de error por colaborador en mi departamento -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Porcentaje de error por colaborador en mi departamento</h6>
                                    <div class="dropdown no-arrow"></div>
                                </div>
                                <!-- Body -->
                                <div class="card-body">     

                                                               <?php

                                                                $totalbyusuario=mysqli_query($conexion,"CALL `sp_totalbyusuario`('$depaactuales');");  

                                                                foreach($totalbyusuario as $data)
                                                                {

                                                                $Nombredelcolaborador[] = $data['Nombredelcolaborador'];
                                                                $Porcentajesigma[] = $data['Porcentajesigma'];
                                                                
                                                                $r = rand(0,255); 
                                                                $g = rand(0,255); 
                                                                $b = rand(0,255); 
                                                                $color2[] = "rgb(".$r.",".$g.",".$b.")";
                                                                }
                                                                ?>
                                                                
                                                                <script>
                                                                const labels = <?php echo json_encode($Nombredelcolaborador)?>;
                                                                    const data = {
                                                                        labels: <?php echo json_encode($Nombredelcolaborador)?>,
                                                                        datasets: [{
                                                                            label: 'Porcentajes',
                                                                            data: <?php echo json_encode($Porcentajesigma)?>,
                                                                            backgroundColor: <?php echo json_encode($color2)?>,
                                                                            hoverOffset: 4
                                                                        }]
                                                                    };

                                                                const config = 
                                                                {
                                                                type: 'doughnut',
                                                                data: data,
                                                                };
                                                                </script>
                                                                
                                                                <div>
                                                                <canvas id="graficoporusuarios2"></canvas>
                                                                </div>

                                                                <script>
                                                                const graficoporusuarios2 = new Chart(
                                                                document.getElementById('graficoporusuarios2'),
                                                                config
                                                                );
                                                                </script>


                                </div>
                            </div>
                        </div>
                    </div>

                                <!-- Guia escala de sigmas -->
                                <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Guia escala de sigmas</h6>
                                </div>
                                <div class="card-body">
                                    <h4 class="small font-weight-bold">Sigma 1<span
                                            class="float-right">30.85 %</span></h4>
                                    <div class="progress mb-4">
                                        <div class="progress-bar bg-danger" role="progressbar" style="width: 31%"
                                            aria-valuenow="31" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <h4 class="small font-weight-bold">Sigma 2<span
                                            class="float-right">69.15 %</span></h4>
                                    <div class="progress mb-4">
                                        <div class="progress-bar bg-warning" role="progressbar" style="width: 70%"
                                            aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <h4 class="small font-weight-bold">Sigma 3<span
                                            class="float-right">93.30 %</span></h4>
                                    <div class="progress mb-4">
                                        <div class="progress-bar" role="progressbar" style="width: 93.30%"
                                            aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <h4 class="small font-weight-bold">Sigma 4<span
                                            class="float-right">99.30 %</span></h4>
                                    <div class="progress mb-4">
                                        <div class="progress-bar bg-info" role="progressbar" style="width: 99.30%"
                                            aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <h4 class="small font-weight-bold">Sigma 5<span
                                            class="float-right">99.98 %</span></h4>
                                    <div class="progress">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 99.98%"
                                            aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <br>
                                    <h4 class="small font-weight-bold">Sigma 6<span
                                            class="float-right">99.9996 %</span></h4>
                                    <div class="progress">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 100%"
                                            aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    
                                </div>
                            </div>


                   

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Estudiantes de la Universiad Americana 2022</span>
                    </div>
                </div>
            </footer>
            <!-- final Footer -->

        </div>
        <!-- final contenido -->

    </div>
    <!-- final contenido  Wrapper -->

    

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Listo para ir?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Seleccione "Logout" si de verdad quieres cerrar la session actual.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="../cerrarsession.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>

