<?php
$dbname = 'proyect';
$dbuser = 'ariel';
$dbpass = 'ariel';
$dbhost = '127.0.0.1';

$conexion = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
if (!$conexion){
    die ("No hay conexion: ".mysqli_connect_error());
}

$nombre=$_POST["departaNombre"];

$existe=mysqli_query($conexion,"SELECT * FROM `departamentos` WHERE nombre='$nombre'");
$array = mysqli_fetch_array($existe);
$existe = $array ['nombre']?? "";


if ($existe == $nombre){
    ?>
    <?php
    include("cdepartamentos.php");
    ?>
    <script LANGUAJE="JavaScript"> alert("Departamento existente, intente otra vez")</script>
    <?php
}  

else{
    mysqli_query($conexion,"INSERT INTO `departamentos`(`nombre`,`valorsigma`) VALUES ('$nombre',0)");
    ?>
   <?php
   include("cdepartamentos.php");
   ?>
   <script LANGUAJE="JavaScript"> alert("Departamento creado con exito!")</script>
   <?php
}
