<?php
$dbname = 'proyect';
$dbuser = 'ariel';
$dbpass = 'ariel';
$dbhost = '127.0.0.1';

$conexion = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
if (!$conexion){
    die ("No hay conexion: ".mysqli_connect_error());
}

$nombre=$_POST["idnombrebox"];
$pass=$_POST["idpass"];
$tipousuario=2;
$id=$_POST["idtextbox"];
$email=$_POST["idemail"]?? "";
$departamento=$_POST["departamentos"];


$existe=mysqli_query($conexion,"SELECT * FROM `usuarios` WHERE id='$id'");
$array = mysqli_fetch_array($existe);
$existeid = $array ['id']?? "";

//$existe2=mysqli_query($conexion,"SELECT * FROM usuarios where email='$email'");
//$array2 = mysqli_fetch_array($existe2);
//$existemail = $array ['email'];
//echo $existemail;


if ($existeid  == $id ){
    ?>
    <?php
    include("cusuarios.php");
    ?>
    <script LANGUAJE="JavaScript"> alert("ID o correo existente, intente otra vez")</script>
    <?php
}  
 
else{
    mysqli_query($conexion,"INSERT INTO `usuarios`(`nombreusuario`, `contrasena`, `tipousuario`, `id`, `email`, `departamento`,`ticketsCerrados`, `ticketsError`, `total`) VALUES ('$nombre','$pass',$tipousuario,'$id','$email','$departamento',0,0,0)");
    ?>
   <?php
   include("cusuarios.php");
   ?>
   <script LANGUAJE="JavaScript"> alert("Usuario creado con exito!")</script>
   <?php

}




