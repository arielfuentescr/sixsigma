<?php 
$dbname = 'proyect';
$dbuser = 'ariel';
$dbpass = 'ariel';
$dbhost = '127.0.0.1';

$conexion5 = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
session_start();
$idsession = $_SESSION["id"];

if ($idsession == ""):
    header("location: ../index.html");
else:
endif;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grafico barras</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>


<body>


<?php
$departamentosigma=mysqli_query($conexion5,"CALL `sp_totalesbyDepartamento`();");
foreach($departamentosigma as $data)
    {

    $Nombredeldepartamento[] = $data['Nombredeldepartamento'];
    $valorsigma[] = $data['valorsigma'];
    
    $r = rand(0,255); 
    $g = rand(0,255); 
    $b = rand(0,255); 
    $c= 0.6;
    $color2[] = "rgb(".$r.",".$g.",".$b.",".$c.")";
    
    }
?>

<script>
const labels = <?php echo json_encode($Nombredeldepartamento)?>;
    const data = {
    labels: labels,
        datasets: [{
            label: 'Porcentaje Sigma',
            data: <?php echo json_encode($valorsigma)?>,
            backgroundColor: <?php echo json_encode($color2)?>,
        }]
    };


const config = {
    type: 'bar',
    data: data,
    options: {
    scales: {
    y: {
    beginAtZero: true
        }
        }
    },
};
</script>
            
<div>
<canvas id="graficoSigmas"></canvas>
</div>
               
<script>
const graficoSigmas = new Chart(
document.getElementById('graficoSigmas'),
config);
</script>


</body>
</html>