<?php
$dbname = 'proyect';
$dbuser = 'ariel';
$dbpass = 'ariel';
$dbhost = '127.0.0.1';

$conexion = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
$conexion2 = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
if (!$conexion){
    die ("No hay conexion: ".mysqli_connect_error());
}

$cantidaddepas=mysqli_query($conexion,"CALL `sp_cantidadepas`();");
$cantidaddecola=mysqli_query($conexion2,"CALL `sp_cantidadcolabo`();");


 while ($row = mysqli_fetch_array($cantidaddecola)){   
    echo $row[0] . "<br>"; 
 }
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>