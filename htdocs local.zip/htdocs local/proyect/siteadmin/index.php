<?php
$dbname = 'proyect';
$dbuser = 'ariel';
$dbpass = 'ariel';
$dbhost = '127.0.0.1';

$conexion = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
$conexion2 = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
$conexion3 = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
$conexion4 = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
$conexion5 = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);

$cantidaddepas=mysqli_query($conexion,"CALL `sp_cantidadepas`();");
$cantidaddecola=mysqli_query($conexion2,"CALL `sp_cantidadcolabo`();");

$departamentos=mysqli_query($conexion4,"SELECT * FROM `departamentos`");

session_start();
$idsession = $_SESSION["id"];

if ($idsession == ""):
    header("location: ../index.html");
else:
endif;



?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SixSigma Dashboard para Admins</title>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!--  fonts-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- estilos boostrap-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar menu azul -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        

            
            <hr class="sidebar-divider my-0">

            <!-- Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Ir al Dashboard</span></a>
            </li>

            
            <hr class="sidebar-divider">

            <!-- Encabezado Herramientas-->
            <div class="sidebar-heading">
                Herramientas
            </div>

            <!--nav del Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Administracion</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Administracion</h6>
                        <a class="collapse-item" href="cusuarios.php">Crear usuarios</a>
                        <a class="collapse-item" href="cdepartamentos.php">Crear departamentos</a>
                    </div>
                </div>
            </li>

           
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Ingreso de datos</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Datos del colaborador</h6>
                        <a class="collapse-item" href="ingresodatos.php">Agregar</a>
                    </div>
                </div>
            </li>

            
            <hr class="sidebar-divider">

    

            <!--nav del Menu -->
            

        </ul>
        <!-- final Sidebar azul-->


        
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- contenido principal -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                       

                                            <!-- dropdown del logout -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <!--  <span class="mr-2 d-none d-lg-inline text-gray-600 small">Douglas McGee</span>--><img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
            
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Inicio info principal-->
                <div class="container-fluid">

                    
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                    </div>

                    
                    <div class="row">



                        <!-- Cantidad de colaboradores -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Cantidad de colaboradores
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                              
                                                <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php
                                                        while ($row = mysqli_fetch_array($cantidaddecola)){   
                                                            echo $row[0] . "<br>"; 
                                                        }
                                                        ?>
                                                </div>
                                                        
                                                </div>
                                                 
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                         <!--  Cantidad de departamentos -->
                         <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Cantidad de departamentos</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"> <?php
                                                while ($row = mysqli_fetch_array($cantidaddepas)){   
                                                    echo $row[0] . "<br>"; 
                                                }
                                                ?>
                                                </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                             </div>
                        </div>
                    </div>

                    

                    <div class="row">

                        <!-- Graficos -->
                        <div class="col-xl-8 col-lg-7">
                            <div class="card shadow mb-4">
                                <!-- Porcentaje Sigma por departamento -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Porcentaje Sigma por departamento</h6>
                                    <div class="dropdown no-arrow">
                                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                        </a>
                                    </div>
                                </div>
                                <!-- Body -->
                                <div class="card-body">
                               
                                <div class="embed-responsive embed-responsive-16by9">
                                 <iframe class="embed-responsive-item" src="/proyect/siteadmin/chartbarras.php"></iframe>
                                </div>  
                                </div>
                            </div>
                        </div>

                       
                        <div class="col-xl-4 col-lg-5">
                            <div class="card shadow mb-4">
                                <!-- Porcentaje de error por colaborado -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Porcentaje de error por colaborador</h6>
                                    <div class="dropdown no-arrow"></div>
                                </div>
                                <!-- Body -->
                                <div class="card-body">     
                                       
                                        <form action="index.php" method="post">
                                            <div class="form-group">
                                            <select name = "departamentoselected" class="form-select" aria-label="Default select example" id = "select_box">
                                                <option value ="">Escoger departamento</option>
                                                <?php
                                                foreach ($departamentos as $row)
                                                {
                                                echo '<option value="'.$row["nombre"].'">'.$row["nombre"].'</option>';
                                                }
                                                ?>
                                            </select>
                                            <button id="submitdepa" type="submit" class="btn btn-primary">Ver o refrescar grafico</button>
                                            </div>
                                        </form>

                                        <?php

                                        $departamentoseleccionado=$_POST["departamentoselected"]?? "";
                                        $totalbyusuario=mysqli_query($conexion3," CALL `sp_totalbyusuario`('$departamentoseleccionado');")?? "";  

                                        foreach($totalbyusuario as $data)
                                        {

                                        $Nombredelcolaborador[] = $data['Nombredelcolaborador'];
                                        $Porcentajesigma[] = $data['Porcentajesigma'];
                                        
                                        $r = rand(0,255); 
                                        $g = rand(0,255); 
                                        $b = rand(0,255); 
                                        $color2[] = "rgb(".$r.",".$g.",".$b.")";
                                        }
                                        ?>

                                        <div>
                                        <canvas id="graficoporusuarios"></canvas>
                                        </div>

                                        <script>
                                        const labels = <?php echo json_encode($Nombredelcolaborador)?>;
                                            const data = {
                                                labels: <?php echo json_encode($Nombredelcolaborador)?>,
                                                    datasets: [{
                                                        label: 'Porcentajes',
                                                        data: <?php echo json_encode($Porcentajesigma)?>,
                                                        backgroundColor: <?php echo json_encode($color2)?>,
                                                        hoverOffset: 4
                                                    }]
                                             };

                                                const config = 
                                                {
                                                type: 'doughnut',
                                                data: data,
                                                };
                                        </script>
                                                    
                                                    
                                        <script>
                                        const graficoporusuarios = new Chart(
                                        document.getElementById('graficoporusuarios'),
                                        config
                                        );
                                        </script>

                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="row">

                       
                        <div class="col-lg-6 mb-4">

                        </div>
                    </div>
                    
                    

                              <!-- Guia escala de sigmas -->
                              <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Guia escala de sigmas</h6>
                                </div>
                                <div class="card-body">
                                    <h4 class="small font-weight-bold">Sigma 1<span
                                            class="float-right">30.85 %</span></h4>
                                    <div class="progress mb-4">
                                        <div class="progress-bar bg-danger" role="progressbar" style="width: 31%"
                                            aria-valuenow="31" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <h4 class="small font-weight-bold">Sigma 2<span
                                            class="float-right">69.15 %</span></h4>
                                    <div class="progress mb-4">
                                        <div class="progress-bar bg-warning" role="progressbar" style="width: 70%"
                                            aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <h4 class="small font-weight-bold">Sigma 3<span
                                            class="float-right">93.30 %</span></h4>
                                    <div class="progress mb-4">
                                        <div class="progress-bar" role="progressbar" style="width: 93.30%"
                                            aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <h4 class="small font-weight-bold">Sigma 4<span
                                            class="float-right">99.30 %</span></h4>
                                    <div class="progress mb-4">
                                        <div class="progress-bar bg-info" role="progressbar" style="width: 99.30%"
                                            aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <h4 class="small font-weight-bold">Sigma 5<span
                                            class="float-right">99.98 %</span></h4>
                                    <div class="progress">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 99.98%"
                                            aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <br>
                                    <h4 class="small font-weight-bold">Sigma 6<span
                                            class="float-right">99.9996 %</span></h4>
                                    <div class="progress">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 100%"
                                            aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    
                                </div>
                            </div>


                   

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Estudiantes de la Universiad Americana 2022</span>
                    </div>
                </div>
            </footer>
            <!-- Final  Footer -->

        </div>
        <!-- final Content Wrapper -->

    </div>
    <!-- final pagina Wrapper -->



    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Listo para ir?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Seleccione "Logout" si de verdad quieres cerrar la session actual.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="../cerrarsession.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>