<?php
$dbname = 'proyect';
$dbuser = 'ariel';
$dbpass = 'ariel';
$dbhost = '127.0.0.1';

$conexion = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
if (!$conexion){
    die ("No hay conexion: ".mysqli_connect_error());
}


$usuario=$_POST["usuario"];
$ticketscerrados=$_POST["ticketscerrados"];
$ticketsNOcerrados=$_POST["ticketsNOcerrados"];

$existe=mysqli_query($conexion,"SELECT * FROM `usuarios` WHERE nombreusuario='$usuario'");
$array = mysqli_fetch_array($existe);
$existe = $array ['nombreusuario'];


if ($existe  == $usuario ){
    
   // mysqli_query($conexion,"UPDATE `usuarios` SET `ticketsCerrados`='$ticketscerrados',`ticketsError`='$ticketsNOcerrados' WHERE nombreusuario = '$usuario'");
   
   mysqli_query($conexion,"CALL sp_agregarDatos($ticketscerrados,$ticketsNOcerrados,'$usuario')");
    ?>
    <?php
    include("ingresodatos.php");
    ?>
    <script LANGUAJE="JavaScript"> alert("Datos guardados con exito")</script>
    <?php
}  


